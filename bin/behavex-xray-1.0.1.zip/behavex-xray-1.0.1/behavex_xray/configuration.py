# -*- encoding: utf-8 -*-

"""
This module process the configuration required
by the framework. Default values are used if no
config file is provided
"""
# pylint: disable=W0603
import logging
import traceback
from os import path
from configobj import ConfigObj
from validate import Validator


def get_config_jira(cfg_path):
    """Returns a dictionary containing
    the jira configuration values"""

    config_jira_spec = """
    [jira]
    jira_instance_url=string(default="")
    xray_api_uri=string(default="")

    [sync]
    json_path=string(default="")
    project_id=string(default="")
    project_key=string(default="")
    test_plan_id=string(default="")
    test_plan_key=string(default="")
    test_plan_summary=string(default="")
    test_execution_summary=string(default="")
    story_tag_regex=string(default="")
    """
    try:
        if not path.isabs(cfg_path):
            cfg_path = path.join(path.abspath(path.curdir), cfg_path)
        spec = config_jira_spec.split('\n')
        validator = Validator()
        config_jira = ConfigObj(cfg_path, configspec=spec)
        config_jira.validate(validator, copy=True)
        return config_jira
    except Exception as ex:
        logging.error(ex)
        print('The configuration file was not provided or it is empty.')
        traceback.print_exc()
        exit()
