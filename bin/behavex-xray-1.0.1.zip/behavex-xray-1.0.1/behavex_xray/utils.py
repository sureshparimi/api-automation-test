# -*- encoding: utf-8 -*-

import json
import logging
import os
import traceback

LEVELS = {'debug': logging.DEBUG,
          'info': logging.INFO,
          'warning': logging.WARNING,
          'error': logging.ERROR,
          'critical': logging.CRITICAL}


def steps_to_string(scenario, steps, back=False):
    """Return string with representation of the step
    """
    return u''.join([_step_to_string(scenario, step, back) for step in steps])


def _step_to_string(scenario, step, back=False):
    """Generate string from scenario"""
    result = u' '
    result += resolving_type(step, scenario, back, white_space=u' ') + u' ' + step['name'] + u'\n'
    if 'table' in step:
        table_length = 0
        space_keys = {}
        for key in step['table']:
            table_length = len(step['table'][key])
            space_key = [len(value) for value in step['table'][key]]
            space_keys.update({key: max([len(key)] + space_key)})
            result += u'{}|{}'.format(u' '*4, key.ljust(space_keys[key], u' '))
        result += u'|\n'

        for i in range(table_length):
            for key in step['table']:
                value = step['table'][key][i]
                result += u'{}|{}'.format(
                    u' '*4, value.ljust(space_keys[key], u' '))
            result += u'|\n'

    return result


def check_json_file(json_path):
    if not os.path.exists(json_path):
        print(u"File not found: '{}'".format(json_path))
        exit()
    else:
        if not json_path.endswith('json'):
            print(u"The provided file is not a .json report: '{}'".format(json_path))
            exit()
        else:
            try:
                execution_file = open(json_path, 'r')
                behavex_execution = json.load(execution_file, encoding='utf8')
                return behavex_execution
            except Exception as exception:
                print(str(exception))
                print(u"It was not possible to open or parse the provided file: '{}'".format(json_path))
                traceback.print_exc()
                exit()


def resolving_type(step, scenario, background=True, white_space='&nbsp;'):
    """Resolving if have that put And or your step_type"""
    if 'index' not in step or step['index'] == 0:
        return step['step_type'].title()
    else:
        steps = scenario['steps']
        if 'background' in step.keys() and not background:
            steps = scenario['background']['steps']
        try:
            previous_type = steps[step['index'] - 1]['step_type']
        except:
            return step['step_type'].title()
        if previous_type == step['step_type']:
            return u'{0}{0}And'.format(white_space)
        else:
            return step['step_type'].title()


def duplicate_scenario_to_file(duplicates):
    """create file duplicate.txt with scenarios duplicated"""
    with open('duplicate.txt', 'w') as file_duplicate:
        for scenario1, scenario2 in duplicates:
            duplicated_msg = 'Scenario name "{}" already exists in the following feature files: ' \
                             '"{}" and "{}"\n'.format(scenario1['name'],
                                                      scenario1['filename'],
                                                      scenario2['filename'])
            print(duplicated_msg)
            file_duplicate.write(duplicated_msg + '\n')
    print('There are duplicated scenario names in file "{}".\n'.format(os.path.abspath(file_duplicate.name)))


def get_logging_level(level):
    return LEVELS[level.lower()]


def config_logger(logging_level):
    level = get_logging_level(logging_level)
    logging.basicConfig(level=level)


def get_duplicated_scenarios(json_result):
    ref_scenarios = {}
    duplicates = []
    for feature in json_result['features']:
        for scenario in feature['scenarios']:
            if scenario['name'].strip() not in ref_scenarios:
                ref_scenarios[scenario['name'].strip()] = scenario
            else:
                duplicates.append((ref_scenarios[scenario['name'].strip()], scenario))
    return duplicates
