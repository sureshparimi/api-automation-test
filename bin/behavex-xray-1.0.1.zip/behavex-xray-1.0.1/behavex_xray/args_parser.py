# -*- encoding: utf-8 -*-
"""Arguments parser"""
import argparse


def parser(args):
    """Arguments parser"""
    parsed = argparse.ArgumentParser(
        description="Library to sync BehaveX elements with Xray for Jira"
        )
    parsed.add_argument('-c',
                        '--config',
                        help='Configuration File path',
                        required=False)
    parsed.add_argument('--logging-level',
                        default="INFO",
                        choices=['CRITICAL', 'ERROR', 'WARNING', 'INFO',
                                 'DEBUG'],
                        help="Logging level (Default: INFO)",
                        required=False)
    parsed.add_argument('-nt',
                        '--no-traceability',
                        help="Do no perform the traceability between test scenarios and Jira elements (based on TAGS)",
                        action='store_true',
                        required=False)
    parsed.add_argument('-unrs',
                        '--update-not-run-status',
                        action='store_false',
                        help="Reset all tests that were originally synced as 'Not Run'. Overrides manual status updates.",
                        required=False)
    parsed.add_argument('-swd',
                        '--sync-with-duplicates',
                        action='store_false',
                        help="Enables syncing a json file containing duplicated test scenarios. "
                             "This option may cause some inconsistencies during synchronization.",
                        required=False)
    parsed.add_argument('-str',
                        '--story-tag-regex',
                        help="The regular expression for find the story in scenario. If not provided \
                                the default regex will be set to '{project_key}-[0-9]+'")
    parsed.add_argument('-jiu',
                        '--jira-instance-url',
                        help="Jira instance url",
                        required=False)
    parsed.add_argument('-xau',
                        '--xray_api_uri',
                        help="Xray API uri",
                        required=False)
    parsed.add_argument('-jp',
                        '--json-path',
                        help="Json path for synchronizing",
                        required=False)
    parsed.add_argument('-pi',
                        '--project-id',
                        help='Jira Project id',
                        required=False)
    parsed.add_argument('-pk',
                        '--project-key',
                        help='Jira Project key',
                        required=False)
    parsed.add_argument('-tpk',
                        '--test-plan-key',
                        help='Jira Test plan key',
                        required=False)
    parsed.add_argument('-tps',
                        '--test-plan-summary',
                        help='Jira Test plan summary',
                        required=False)
    parsed.add_argument('-tes',
                        '--test-execution-summary',
                        help='Jira Test Execution summary',
                        required=False)
    return parsed.parse_args(args)
