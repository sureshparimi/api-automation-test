# -*- encoding: utf-8 -*-
import logging
import os
import sys
import traceback
from .args_parser import parser
from .run_sync import RunSync, get_param_config
from .configuration import get_config_jira
from .utils import (
    config_logger,
    get_duplicated_scenarios,
    duplicate_scenario_to_file,
    check_json_file,
)


def check_duplicates(json):
    duplicated_scenario = get_duplicated_scenarios(json)
    if duplicated_scenario:
        duplicate_scenario_to_file(duplicated_scenario)
        return True
    return False


def load_args_from_config(xray_args, config_jira):
    try:
        if xray_args.jira_instance_url:
            config_jira['jira'].update({'jira_instance_url': xray_args.jira_instance_url})
        if xray_args.xray_api_uri:
            config_jira['jira'].update({'xray_api_uri': xray_args.xray_api_uri})
        if xray_args.json_path:
            config_jira['sync'].update({'json_path': xray_args.json_path})
        if xray_args.project_id:
            config_jira['sync'].update({'project_id': xray_args.project_id})
        if xray_args.project_key:
            config_jira['sync'].update({'project_key': xray_args.project_key})
        if xray_args.test_plan_key:
            config_jira['sync'].update({'test_plan_key': xray_args.test_plan_key})
        if xray_args.test_plan_summary:
            config_jira['sync'].update({'test_plan_summary': xray_args.test_plan_summary})
        if xray_args.test_execution_summary:
            config_jira['sync'].update({'test_execution_summary': xray_args.test_execution_summary})
        if xray_args.story_tag_regex:
            config_jira['sync'].update({'story_tag_regex': xray_args.story_tag_regex})
        if xray_args.no_traceability:
            config_jira['sync'].update({'no_traceability': 'True'})
        if xray_args.update_not_run_status:
            config_jira['sync'].update({'update_not_run_status': 'True'})
        return config_jira
    except Exception as ex:
        logging.error(ex)
        print("Field required or wrong value provided...")
        traceback.print_exc()


def check_delete(config_jira, args):
    """ Delete issues, when? """
    pass


def main():
    try:
        xray_args = parser(sys.argv[1:])
        config_jira = get_config_jira(xray_args.config)
        config_jira = load_args_from_config(xray_args, config_jira)
        config_jira["jira_instance_url"] = get_param_config(config_jira, 'jira.jira_instance_url')
        config_jira["xray_api_uri"] = get_param_config(config_jira, 'jira.xray_api_uri')
        if "JIRA_USER_EMAIL" in os.environ and \
                "JIRA_API_TOKEN" in os.environ and \
                "XRAY_CLIENT_ID" in os.environ and \
                "XRAY_CLIENT_SECRET" in os.environ:
            config_jira["jira_user_email"] = os.environ.get('JIRA_USER_EMAIL', None)
            config_jira["jira_api_token"] = os.environ.get('JIRA_API_TOKEN', None)
            config_jira["xray_client_id"] = os.environ.get('XRAY_CLIENT_ID', None)
            config_jira["xray_client_secret"] = os.environ.get('XRAY_CLIENT_SECRET', None)
        else:
            raise Exception(
                "Some env. variables are missing (JIRA_USER_EMAIL, JIRA_API_TOKEN, XRAY_CLIENT_ID, XRAY_CLIENT_SECRET)")
        json_to_sync = check_json_file(get_param_config(config_jira, 'sync.json_path'))
        if check_duplicates(json_to_sync):
            if xray_args.sync_with_duplicates:
                print(u"""This json contains duplicated scenarios,
                      please use the --sync-with-duplicates argument 
                      to proceed, but this option may cause some inconsistencies.""")
                exit(0)
        config_logger(xray_args.logging_level)
        # Start sync test
        print('Synchronizing test scenarios...')
        runner = RunSync(config_jira,
                         json_to_sync)
        is_execution = '' != get_param_config(config_jira, 'sync.test_plan_summary') or \
                       '' != get_param_config(config_jira, 'sync.test_plan_key')

        if is_execution:
            runner.test_plan = runner.get_test_plan()
            runner.test_exec = runner.get_test_exec()
        print('Uploading test scenarios to JIRA... ')
        runner.start_sync(is_execution)
        if runner.xray_project.error:
            print('An error has occurred')
            exit(-1)
        else:
            print('JIRA synchronization completed.')
    except Exception as ex:
        logging.error(ex)
        traceback.print_exc()
        exit(-1)


if __name__ == '__main__':
    main()
