# -*- encoding: utf-8 -*-
import logging
import re
import traceback

from .xray_project import XrayProject
from .utils import steps_to_string

STATUS_DICT = {
    'failed': 'FAILED', 'passed': 'PASSED', 'skipped': 'TO DO'
}


class RunSync(object):
    """ class to synchronize the json file with jira """

    def __init__(self, config_jira, json_to_sync):
        self.config_jira = config_jira
        self.json_to_sync = json_to_sync
        self.xray_project = XrayProject(self.config_jira['jira_instance_url'],
                                        self.config_jira['jira_user_email'],
                                        self.config_jira['jira_api_token'],
                                        self.config_jira['xray_api_uri'],
                                        self.config_jira['xray_client_id'],
                                        self.config_jira['xray_client_secret'])
        self.test_plan = None
        self.test_exec = None
        self.dict_test_set = None
        self.dict_precondition = None
        self.dict_stories = None
        self.get_jira_project()
        self.xray_project.create_dict_fields()
        self.environment = self.json_to_sync['environment']

    def get_jira_project(self):
        project_key = get_param_config(self.config_jira, 'sync.project_key')
        project_id = get_param_config(self.config_jira, 'sync.project_id')
        if project_id:
            self.xray_project.get_project_by(find_by='id', value=project_id)
        elif project_key:
            self.xray_project.get_project_by(find_by='key', value=project_key)
        print('Jira project: {}'.format(self.xray_project.project.key))
        self.xray_project.get_issues_types(project_key)

    def get_test_plan(self):
        test_plan = None
        for field in ['key', 'id']:
            plan = get_param_config(self.config_jira, 'sync.test_plan_{}'.format(field))
            if plan:
                test_plan = self.xray_project.get_issue('Test Plan', field, plan)
        if not test_plan:
            test_plan_summary = get_param_config(self.config_jira, 'sync.test_plan_summary')
            if not test_plan_summary:
                raise Exception("Test plan summary was not provided...")
            test_plan = self.xray_project.get_issue('Test Plan', 'summary', test_plan_summary)
            if not test_plan:
                dict_names, dict_keys, created_test_plan = self.xray_project.create_test_plan(test_plan_summary)
                test_plan = created_test_plan[0]
        print('Jira test plan: {}'.format(test_plan.fields.summary))
        return test_plan

    def get_test_exec(self, exec_key=None):
        if exec_key:
            test_exec = self.xray_project.get_issue('Test Execution', 'key', exec_key)
        else:
            exec_summary = get_param_config(self.config_jira, 'sync.test_execution_summary')
            if not exec_summary:
                exec_summary = self.test_plan.fields.summary + ' (Test execution)'
            test_exec = self.xray_project.get_issue('Test Execution', 'summary', exec_summary)
        if not test_exec:
            dict_names, dict_keys, created_test_exec = self.xray_project.create_test_execution(exec_summary)
            test_exec = created_test_exec[0]
        self.xray_project.add_test_execution_to_test_plan(self.test_plan.id, test_exec.id)
        print('Jira test execution: {}'.format(test_exec.fields.summary))
        return test_exec

    def start_sync(self, is_execution, update=False):
        dict_name_tests, dict_key_tests, issues_tests = self.xray_project.get_issues('Test')
        if is_execution:
            tests_exec_key = self.xray_project.get_tests_from_test_run(self.test_exec.id)
            tests_plan_key = self.xray_project.get_tests_from_test_plan(self.test_plan.id)
        else:
            tests_exec_key = None
            tests_plan_key = None
        skipped = get_param_config(self.config_jira, 'sync.update_not_run_status')
        iter_issues = IterIssuesToSync(dict_name_tests,  # test_name: issue object
                                       self.json_to_sync['features'],
                                       tests_plan_key,
                                       tests_exec_key,
                                       update,
                                       bool(skipped))
        if not get_param_config(self.config_jira, 'sync.no_traceability'):
            self.create_dict_stories()

        for issues_to_sync in iter_issues:
            self.sync_tests(issues_tests, tests_exec_key, issues_to_sync)

        if is_execution:
            dict_tests_key = {issue.fields.summary: issue for issue in issues_tests if issue.key in tests_exec_key}
        else:
            dict_tests_key = {issue.fields.summary: issue for issue in issues_tests}
        tests_set_name = self.create_dict_test_set(dict_tests_key)
        for test_set_summary, tests_names in self.dict_test_set.items():
            to_test_set = []
            for test_name in tests_names:
                if test_name in dict_tests_key:
                    to_test_set.append(dict_tests_key[test_name].id)
            if to_test_set:
                print('Adding {} tests to Test Set {}'.format(len(to_test_set), test_set_summary))
                self.xray_project.add_test_to_test_set(tests_set_name[test_set_summary].id, to_test_set)

        self.create_dict_precondition(dict_tests_key)
        for precond_id in self.dict_precondition:
            to_precond = []
            for scenario_name in self.dict_precondition[precond_id]:
                if scenario_name in dict_tests_key:
                    to_precond.append(dict_tests_key[scenario_name].id)
            if to_precond:
                self.xray_project.add_test_to_precondition(precond_id, to_precond)
                print('Adding pre-condition {} to test scenarios {}'.format(precond_id, to_precond))
        if update:
            self.test_exec.update()

    def sync_tests(self, tests, tests_exec_key, issues_to_sync):
        try:
            dict_scenarios, to_create, to_update, to_update_status, to_add_plan, to_add_exec = issues_to_sync
            is_execution = self.test_plan is not None
            if to_create:
                tests += self.upload_tests(to_create)
            if to_update:
                for issue, scenario in to_update:
                    gherkin_def = ""
                    for step in steps_to_string(scenario, scenario['steps']).split("\n"):
                        gherkin_def += step.replace("\"", "\\\"") + "\\n"
                    self.xray_project.update_test_scenario_gherkin(issue.id, gherkin_def)
                    issue.update(fields={'labels': scenario['tags'],
                                         'description': steps_to_string(scenario, scenario['steps'])})
                print('{} tests scenarios updated successfully'.format(len(to_update)))
            tests_updated = []
            if is_execution:
                if to_update_status:
                    print('Updating status for {} Test'.format(len(to_update_status)))
                    updated_execution_status = []
                    for test_key, status, comment in to_update_status:
                        updated_execution_status.append({"testKey": test_key,
                                                         "status": status,
                                                         "comment": comment})
                        tests_updated.append(test_key)
                    if updated_execution_status:
                        self.xray_project.update_test_run_status(self.test_exec.key, updated_execution_status)
                if to_add_plan:
                    print('Adding {} tests to test plan {}'.format(len(to_add_plan), self.test_plan.fields.summary))
                    self.xray_project.add_tests_to_test_plan(self.test_plan.id, to_add_plan)
                if to_add_exec:
                    print(
                        'Adding {} tests to test execution {}'.format(len(to_add_exec), self.test_exec.fields.summary))
                    self.xray_project.add_tests_to_test_execution(self.test_exec.id, to_add_exec)
                new_test_exec = self.xray_project.get_tests_from_test_run(self.test_exec.id)
                tests_exec_key.update(new_test_exec)
                dict_tests_key = {issue.fields.summary: issue for issue in tests if issue.key in tests_exec_key}
            else:
                dict_tests_key = {issue.fields.summary: issue for issue in tests}

            updated_execution_status = []
            for scenario_name, scenario in dict_scenarios.items():
                if scenario_name in dict_tests_key:
                    issue = dict_tests_key[scenario_name]
                    if is_execution and (issue.key not in tests_updated):
                        test_status = tests_exec_key[issue.key]["status"]["name"]
                        if STATUS_DICT[scenario['status']] != test_status.upper():
                            comment = scenario['error_msg']
                            updated_execution_status.append({"testKey": issue.key,
                                                             "status": STATUS_DICT[scenario['status']],
                                                             "comment": comment})
                    if scenario_name in self.dict_stories:
                        issuelinks_keys = []
                        for issuelink in issue.fields.issuelinks:
                            if hasattr(issuelink, 'outwardIssue'):
                                issuelinks_keys.append(issuelink.outwardIssue.key)
                        story_keys = []
                        for story_key in self.dict_stories[scenario_name]:
                            if story_key not in issuelinks_keys:
                                self.xray_project.link_test_to_jira_elem(story_key, issue.key)
                                story_keys.append(story_key)
                        if story_keys:
                            print('Linking test scenario {} to story {}'.format(issue.key, story_keys))
            if updated_execution_status:
                self.xray_project.update_test_run_status(self.test_exec.key, updated_execution_status)
        except Exception as ex:
            logging.error(ex)
            print('An error has occurred while synchronizing tests...')
            traceback.print_exc()
            exit(-1)

    def upload_tests(self, scenarios):
        """ create test and link these with test plan, excecution and set """
        dict_names, dict_keys, created_tests = self.xray_project.create_tests(scenarios)
        if dict_keys:
            tests_ids = [issue.id for issue in created_tests]
            if self.test_plan and self.test_exec:
                self.xray_project.add_tests_to_test_plan(self.test_plan.id, tests_ids)
                self.xray_project.add_tests_to_test_execution(self.test_exec.id, tests_ids)
            print('{} test scenarios created successfully'.format(len(tests_ids)))
        return created_tests

    def upload_preconditions(self, pre_conditions):
        created_precond = self.xray_project.create_preconditions(pre_conditions)
        result = {}
        if created_precond:
            for precond in created_precond:
                result.update({precond.fields.summary: precond.id})
        return result

    def create_dict_test_set(self, dict_tests_key):
        """ Create a dict with test_set_key as key and one list of scenarios names as value"""
        self.dict_test_set = {}
        tests_set_name, _, _ = self.xray_project.get_issues('Test Set')
        for feature in self.json_to_sync['features']:
            if feature['name'] not in tests_set_name:
                dict_names, dict_keys, created_test_set = self.xray_project.create_test_set(feature['name'])
                test_set = created_test_set[0]
                tests_set_name.update({test_set.fields.summary: test_set})
            test_set_summary = tests_set_name[feature['name']].fields.summary
            test_set_key = tests_set_name[feature['name']].key
            test_in_test_set = self.xray_project.get_tests_from_test_set(test_set_key)
            self.dict_test_set[test_set_summary] = []
            for scenario in feature['scenarios']:
                if scenario['name'].strip() in dict_tests_key.keys():
                    if dict_tests_key[scenario['name'].strip()].key not in test_in_test_set:
                        self.dict_test_set[test_set_summary].append(scenario['name'].strip())
        return tests_set_name

    def create_dict_precondition(self, dict_tests_key):
        """ Create a dict with jira_pre-condition_key as key and list of scenarios name as value """
        self.dict_precondition = {}
        precond_to_create = []
        precond_dict = {}
        precond_name, _, _ = self.xray_project.get_issues('Precondition')
        for feature in self.json_to_sync['features']:
            if not feature['background']:
                continue
            if feature['name'] not in precond_name:
                precond_to_create.append((feature['name'], feature['background']['steps']))
                test_in_pre_cond = []
            else:
                precondition_id = precond_name[feature['name']].id
                test_in_pre_cond = self.xray_project.get_tests_from_precondition(precondition_id)
            precond_dict[feature['name']] = []
            for scenario in feature['scenarios']:
                if dict_tests_key[scenario['name'].strip()].key not in test_in_pre_cond:
                    precond_dict[feature['name']].append(scenario['name'].strip())

        precond_jira = dict(self.upload_preconditions(precond_to_create),  # dict with name:key jira preconditions
                            **{name: precond_name[name].id for name in precond_name if name in
                               [feature['name'] for feature in self.json_to_sync['features']]})
        for name, jiraid in precond_jira.items():
            if name in precond_dict:
                self.dict_precondition[jiraid] = precond_dict[name]
            else:
                # TODO: Delete precondition, as it is no loger part of the scenario
                continue

    def create_dict_stories(self):
        self.dict_stories = {}
        story_tag_reg = get_param_config(self.config_jira, 'sync.story_tag_regex')
        if not story_tag_reg:
            story_tag_reg = r'{}-[0-9]+'.format(self.xray_project.project.key)
        story_match = re.compile(story_tag_reg)

        for feature in self.json_to_sync['features']:
            for scenario in feature['scenarios']:
                for tag in scenario['tags']:
                    if story_match.match(tag):
                        if scenario['name'].strip() in self.dict_stories:
                            self.dict_stories[scenario['name'].strip()].append(tag)
                        else:
                            self.dict_stories[scenario['name'].strip()] = [tag]


class IterIssuesToSync:
    """ class to analyze the json file and group the tests according to the operation to be performed """

    def __init__(self, issues_test, features, test_plan_keys_tests, test_exec_keys_tests,
                 update=False, skipped=False):
        self.issues_test = issues_test
        self.features = features
        self.test_plan_keys_tests = test_plan_keys_tests
        self.test_exec_keys_tests = test_exec_keys_tests
        self.is_execution = test_plan_keys_tests is not None
        self.update = update
        self.skipped = skipped
        self.length = len(features)
        self.index = 0
        self.scenarios = []
        count = 0
        for feature in self.features:
            count += len(feature['scenarios'])
        print('{} test scenarios found in JSON file...'.format(count))
        self.total_scenarios = int(count + 1)

    def __iter__(self):
        return self

    def next(self):
        if self.index >= self.length:
            if self.scenarios:
                return self.get_chunk()
            raise StopIteration("There is not more elements")
        while len(self.scenarios) <= self.total_scenarios and self.index < self.length:
            self.scenarios += self.features[self.index]['scenarios']
            self.index += 1
        else:
            return self.get_chunk()

    def __next__(self):
        return self.next()

    def get_chunk(self):
        scenarios = self.scenarios[:self.total_scenarios]
        dict_scenario, to_create, to_update, to_update_status, to_add_plan, to_add_exec = self.resolve_issues(scenarios)
        if len(self.scenarios) > self.total_scenarios:
            self.scenarios = self.scenarios[self.total_scenarios:]
        else:
            self.scenarios = []
        return dict_scenario, to_create, to_update, to_update_status, to_add_plan, to_add_exec

    def resolve_issues(self, scenarios):
        dict_scenario = {}
        to_create, to_update, to_update_status, to_add_plan, to_add_exec = [], [], [], [], []
        for scenario in scenarios:
            scenario_name = scenario['name'].strip()
            dict_scenario[scenario_name] = scenario
            if scenario_name in self.issues_test:
                issue = self.issues_test[scenario_name]
                if has_changed(issue, scenario):
                    to_update.append((issue, scenario))
                if self.is_execution:
                    if issue.key not in self.test_plan_keys_tests:
                        to_add_plan.append(issue.id)
                    if issue.key in self.test_exec_keys_tests:
                        issue_run = self.test_exec_keys_tests[issue.key]
                        if issue_run['status'] != STATUS_DICT[scenario['status']]:
                            if not (self.update and ('MANUAL' in scenario['tags'] or self.skipped)):
                                to_update_status.append((issue.key,
                                                         STATUS_DICT[scenario['status']],
                                                         scenario['error_msg']))
                    else:
                        to_add_exec.append(issue.id)
            else:
                to_create.append(scenario)
        return dict_scenario, to_create, to_update, to_update_status, to_add_plan, to_add_exec


def get_param_config(dictionary, key_chain):
    """ Get value from config file """
    keys = key_chain.split('.')
    for key in keys:
        result = dictionary.get(key, '')
        if isinstance(result, str):
            return result
        if isinstance(result, dict):
            dictionary = result
        else:
            return ''
    return ''


def has_changed(issue_test, scenario):
    scenario_steps = steps_to_string(scenario, scenario['steps'])
    compress_text = lambda gherkin_text: gherkin_text.lower().strip().\
        replace(" ", ""). \
        replace("and", ""). \
        replace("given", ""). \
        replace("when", ""). \
        replace("then", "")
    compressed_scenario_steps = compress_text(scenario_steps)
    compressed_current_steps = compress_text(issue_test.fields.description)
    if compressed_scenario_steps != compressed_current_steps:
        return True
    if set(scenario['tags']) != set(issue_test.fields.labels):
        return True
    return False
