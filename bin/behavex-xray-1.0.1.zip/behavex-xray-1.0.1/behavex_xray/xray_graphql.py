# -*- encoding: utf-8 -*-
import json
import time
from urllib.parse import urljoin

import requests


class XrayGraphQL:

    def __init__(self, xray_api_uri, xray_client_id, xray_client_secret):
        self.api_uri = xray_api_uri
        self.client_id = xray_client_id
        self.client_secret = xray_client_secret
        self.access_token = self.__generate_token(self.client_id, self.client_secret)

    def __generate_token(self, client_id, client_secret):
        # preparing request
        url = urljoin(self.api_uri, "authenticate")
        headers = {'Content-type': 'application/json', 'Accept': 'text/plain'}
        data = {"client_id": client_id, "client_secret": client_secret}
        # performing HTTP request
        response = requests.post(url, data=json.dumps(data), headers=headers)
        # managing response data
        access_token = None
        if response.status_code == 200:
            access_token = response.text.replace("\"", "")
        else:
            self.raise_http_error(response)
        return access_token

    def __get_request(self, url, query=None):
        headers = {'Content-type': 'application/json', 'Acceptt': 'text/plain'}
        url = urljoin(self.api_uri, url)
        params = {'auth': self.auth, 'url': url, 'headers': headers}
        if query:
            params['params'] = query
        return requests.get(**params)

    def create_tests(self, tests_list):
        # performing bulk insert
        url = urljoin(self.api_uri, "import/test/bulk")
        headers = {'Content-type': 'application/json',
                   'Accept': 'text/plain',
                   'Authorization': 'Bearer {}'.format(self.access_token)}
        bulk_response = requests.post(url, data=json.dumps(tests_list), headers=headers)
        if bulk_response.status_code != 200:
            self.raise_http_error(bulk_response)
        job_id = json.loads(bulk_response.text)["jobId"]
        # obtaining bulk insert status based on the returned "JobId"
        time.sleep(2)
        url = urljoin(self.api_uri, "import/test/bulk/{}/status".format(job_id))
        headers = {'Content-type': 'application/json',
                   'Accept': 'text/plain',
                   'Authorization': 'Bearer {}'.format(self.access_token)}
        for i in range(1000):
            bulk_status = requests.get(url, headers=headers)
            if bulk_response.status_code != 200:
                self.raise_http_error(bulk_status)
            bulk_status_dict = json.loads(bulk_status.text)
            if bulk_status_dict["status"].lower() not in ["successful", "failed"]:
                time.sleep(1)
            else:
                return json.loads(bulk_status.text)

    def create_precondition(self, project_key, precondition_name, steps):
        url = urljoin(self.api_uri, "graphql")
        headers = {'Content-type': 'application/json',
                   'Accept': 'text/plain',
                   'Authorization': 'Bearer {}'.format(self.access_token)}
        query_template = """
            mutation {{
                createPrecondition(
                    preconditionType: {{ name: "Cucumber" }}
                    definition: "{0}"
                    jira: {{
                        fields: {{ summary:"{1}", 
                                   project: {{key: "{2}"}}, 
                                   customfield_10054: {{value: "Forecasting"}}}}
                    }}
                ) {{
                    precondition {{
                        issueId
                        preconditionType {{
                            name
                        }}
                        definition
                        jira(fields: ["key"])
                    }}
                    warnings
                }}
            }}
        """
        query = query_template.format(steps, precondition_name, project_key)
        response = requests.post(url, json={'query': query}, headers=headers)
        if response.status_code != 200:
            self.raise_http_error(response)
        return json.loads(response.text)

    def create_test_set(self, project_key, summary):
        # insert test set
        url = urljoin(self.api_uri, "graphql")
        headers = {'Content-type': 'application/json',
                   'Accept': 'text/plain',
                   'Authorization': 'Bearer {}'.format(self.access_token)}
        query_template = """
            mutation
            {{
                createTestSet(
                    testIssueIds: []
                jira: {{
                    fields: {{
                        summary: "{0}",
                        description: "{0}",
                        project: {{key: "{1}"}},
                        customfield_10054: {{value: "Forecasting"}}
                    }}
                }}
                ) {{
                    testSet
                    {{
                        issueId
                        jira(fields: ["key"])
                    }}
                    warnings
                }}
            }}
        """
        query = query_template.format(summary, project_key)
        response = requests.post(url, json={'query': query}, headers=headers)
        if response.status_code != 200:
            self.raise_http_error(response)
        return json.loads(response.text)

    def create_test_plan(self, project_key, summary):
        url = urljoin(self.api_uri, "graphql")
        headers = {'Content-type': 'application/json',
                   'Accept': 'text/plain',
                   'Authorization': 'Bearer {}'.format(self.access_token)}
        query_template = """
            mutation {{
                createTestPlan(
                    testIssueIds: []
                    jira: {{
                        fields: {{
                            summary: "{0}",
                            project: {{key: "{1}"}}, 
                            customfield_10054: {{value: "Forecasting"}}
                        }}
                    }}
                ) {{
                    testPlan {{
                        issueId
                        jira(fields: ["key"])
                    }}
                    warnings
                }}
            }}
        """
        query = query_template.format(summary, project_key)
        response = requests.post(url, json={'query': query}, headers=headers)
        if response.status_code != 200:
            self.raise_http_error(response)
        return json.loads(response.text)

    def create_test_execution(self, project_key, summary):
        url = urljoin(self.api_uri, "graphql")
        headers = {'Content-type': 'application/json',
                   'Accept': 'text/plain',
                   'Authorization': 'Bearer {}'.format(self.access_token)}
        query_template = """
            mutation {{
                createTestExecution(
                    testIssueIds: []
                    jira: {{
                        fields: {{
                            summary: "{0}",
                            project: {{key: "{1}"}}, 
                            customfield_10054: {{value: "Forecasting"}} 
                        }}
                    }}
                ) {{
                    testExecution {{
                        issueId
                        jira(fields: ["key"])
                    }}
                    warnings
                }}
            }}
        """
        query = query_template.format(summary, project_key)
        response = requests.post(url, json={'query': query}, headers=headers)
        if response.status_code != 200:
            self.raise_http_error(response)
        return json.loads(response.text)

    def get_tests_from_test_set(self, test_set_key):
        limit = 100
        total_tests = 0
        full_response = None
        for i in range(20):
            # print("Retrieving tests from test set from page {} (page size: {})".format(i + 1, limit))
            response = self.get_tests_from_test_set_by_page(test_set_key, limit, i*limit)
            response_results = response["data"]["getTestSets"]["results"][0]["tests"]["results"]
            if not full_response:
                full_response = response
                total_tests = int(response["data"]["getTestSets"]["results"][0]["tests"]["total"])
            else:
                if response_results:
                    full_response["data"]["getTestSets"]["results"][0]["tests"]["results"].extend(response_results)
                else:
                    break
            if (i+1)*limit > total_tests:
                break
        return full_response

    def get_tests_from_test_set_by_page(self, test_set_key, limit=100, start=0):
        # insert test set
        url = urljoin(self.api_uri, "graphql")
        headers = {'Content-type': 'application/json',
                   'Accept': 'text/plain',
                   'Authorization': 'Bearer {}'.format(self.access_token)}
        query_template = """
            {{
              getTestSets(jql: "key={0}", limit: 1) {{
                results {{
                  issueId
                  jira(fields: ["key", "summary"])
                  tests(limit: {1}, start: {2}) {{
                    total
                    results {{
                      issueId
                      jira(fields: ["key", "summary"])
                      testType {{
                          name
                          kind
                      }}
                    }}
                  }}
                }}
              }}
            }}
        """
        query = query_template.format(test_set_key, limit, start)
        response = requests.get(url, json={'query': query}, headers=headers)
        if response.status_code != 200:
            self.raise_http_error(response)
        return json.loads(response.text)

    def get_tests_from_precondition(self, precondition_id):
        limit = 100
        total_tests = 0
        full_response = None
        for i in range(20):
            # print("Retrieving tests from precondition from page {} (page size: {})".format(i + 1, limit))
            response = self.get_tests_from_precondition_by_page(precondition_id, limit, i*limit)
            response_results = response["data"]["getPrecondition"]["tests"]["results"]
            if not full_response:
                full_response = response
                total_tests = int(response["data"]["getPrecondition"]["tests"]["total"])
            else:
                if response_results:
                    full_response["data"]["getPrecondition"]["tests"]["results"].extend(response_results)
                else:
                    break
            if (i+1)*limit > total_tests:
                break
        return full_response

    def get_tests_from_precondition_by_page(self, precondition_id, limit=100, start=0):
        # insert test set
        url = urljoin(self.api_uri, "graphql")
        headers = {'Content-type': 'application/json',
                   'Accept': 'text/plain',
                   'Authorization': 'Bearer {}'.format(self.access_token)}
        query_template = """
            {{
                getPrecondition(issueId: "{0}") {{
                    issueId
                    jira(fields: ["key", "summary"])
                    tests(limit: {1}, start: {2}) {{
                        total
                        results {{
                            issueId
                            jira(fields: ["key", "summary"])
                            projectId
                            testType {{
                                name
                                kind
                            }}
                        }}
                    }}
                }}
            }}
        """
        query = query_template.format(precondition_id, limit, start)
        response = requests.get(url, json={'query': query}, headers=headers)
        if response.status_code != 200:
            self.raise_http_error(response)
        return json.loads(response.text)

    def get_tests_from_test_run(self, test_exec_id):
        limit = 100
        total_tests = 0
        full_response = None
        for i in range(20):
            # print("Retrieving tests from test execution from page {} (page size: {})".format(i + 1, limit))
            response = self.get_tests_from_test_run_by_page(test_exec_id, limit, i*limit)
            response_results = response["data"]["getTestRuns"]["results"]
            if not full_response:
                full_response = response
                total_tests = int(response["data"]["getTestRuns"]["total"])
            else:
                if response_results:
                    full_response["data"]["getTestRuns"]["results"].extend(response_results)
                else:
                    break
            if (i+1)*limit > total_tests:
                break
        return full_response

    def get_tests_from_test_run_by_page(self, test_exec_id, limit=100, start=0):
        url = urljoin(self.api_uri, "graphql")
        headers = {'Content-type': 'application/json',
                   'Accept': 'text/plain',
                   'Authorization': 'Bearer {}'.format(self.access_token)}
        query_template = """
            {{
                getTestRuns( testExecIssueIds: ["{0}"], limit: {1}, start: {2}) {{
                    total
                    results {{
                        id
                        status {{
                            name
                            color
                            description
                        }}
                        gherkin
                        examples {{
                            id
                            status {{
                            name
                            color
                            description
                            }}
                        }}
                        test {{
                            issueId
                            jira(fields: ["id", "key", "summary", "status"])
                        }}
                        testExecution {{
                            issueId
                            jira(fields: ["key"])
                        }}
                    }}
                }}
            }}        
        """
        query = query_template.format(test_exec_id, limit, start)
        response = requests.get(url, json={'query': query}, headers=headers)
        if response.status_code != 200:
            self.raise_http_error(response)
        return json.loads(response.text)

    def get_tests_from_test_plan(self, test_plan_id):
        limit = 100
        total_tests = 0
        full_response = None
        for i in range(20):
            # print("Retrieving tests from test plan from page {} (page size: {})".format(i + 1, limit))
            response = self.get_tests_from_test_plan_by_page(test_plan_id, limit, i*limit)
            response_results = response["data"]["getTestPlan"]["tests"]["results"]
            if not full_response:
                full_response = response
                total_tests = int(response["data"]["getTestPlan"]["tests"]["total"])
            else:
                if response_results:
                    full_response["data"]["getTestPlan"]["tests"]["results"].extend(response_results)
                else:
                    break
            if (i+1)*limit > total_tests:
                break
        return full_response

    def get_tests_from_test_plan_by_page(self, test_plan_id, limit=100, start=0):
        url = urljoin(self.api_uri, "graphql")
        headers = {'Content-type': 'application/json',
                   'Accept': 'text/plain',
                   'Authorization': 'Bearer {}'.format(self.access_token)}
        query_template = """
            {{
                getTestPlan(issueId: "{0}") {{
                    issueId
                    jira(fields: ["key"])
                    tests(limit: {1}, start: {2}) {{
                        total
                        start
                        limit
                        results {{
                            issueId
                            jira(fields: ["key"])
                            projectId
                            testType {{
                                name
                                kind
                            }}
                            status {{
                                name
                            }}
                        }}
                    }}
                }}
            }}
        """
        query = query_template.format(test_plan_id, limit, start)
        response = requests.get(url, json={'query': query}, headers=headers)
        if response.status_code != 200:
            self.raise_http_error(response)
        return json.loads(response.text)

    def add_test_to_test_plan(self, test_plan_id, tests_keys):
        url = urljoin(self.api_uri, "graphql")
        headers = {'Content-type': 'application/json',
                   'Accept': 'text/plain',
                   'Authorization': 'Bearer {}'.format(self.access_token)}
        query_template = """
            mutation {{
                addTestsToTestPlan(
                    issueId: "{0}",
                    testIssueIds: {1}
                ) {{
                    addedTests
                    warning
                }}
            }}
        """
        query = query_template.format(test_plan_id, str(list(set(tests_keys))).replace("'", "\""))
        response = requests.post(url, json={'query': query}, headers=headers)
        if response.status_code != 200:
            self.raise_http_error(response)
        return json.loads(response.text)

    def add_test_to_test_execution(self, test_exec_id, tests_keys):
        url = urljoin(self.api_uri, "graphql")
        headers = {'Content-type': 'application/json',
                   'Accept': 'text/plain',
                   'Authorization': 'Bearer {}'.format(self.access_token)}
        query_template = """
            mutation {{
                addTestsToTestExecution(
                    issueId: "{0}",
                    testIssueIds: {1}
                ) {{
                    addedTests
                    warning
                }}
            }}
        """
        query = query_template.format(test_exec_id, str(list(set(tests_keys))).replace("'", "\""))
        response = requests.post(url, json={'query': query}, headers=headers)
        if response.status_code != 200:
            self.raise_http_error(response)
        return json.loads(response.text)

    def add_test_to_test_set(self, test_set_id, tests_ids):
        url = urljoin(self.api_uri, "graphql")
        headers = {'Content-type': 'application/json',
                   'Accept': 'text/plain',
                   'Authorization': 'Bearer {}'.format(self.access_token)}
        query_template = """
            mutation {{
                addTestsToTestSet(
                    issueId: "{0}",
                    testIssueIds: {1}
                ) {{
                    addedTests
                    warning
                }}
            }}
          """
        query = query_template.format(test_set_id, str(list(set(tests_ids))).replace("'", "\""))
        response = requests.post(url, json={'query': query}, headers=headers)
        if response.status_code != 200:
            self.raise_http_error(response)
        return json.loads(response.text)

    def add_test_to_precondition(self, precondition_id, tests_ids):
        url = urljoin(self.api_uri, "graphql")
        headers = {'Content-type': 'application/json',
                   'Accept': 'text/plain',
                   'Authorization': 'Bearer {}'.format(self.access_token)}
        query_template = """
            mutation {{
                addTestsToPrecondition(
                    issueId: "{0}",
                    testIssueIds: {1}
                ) {{
                    addedTests
                    warning
                }}
            }}
        """
        query = query_template.format(precondition_id, str(tests_ids).replace("'", "\""))
        response = requests.post(url, json={'query': query}, headers=headers)
        if response.status_code != 200:
            self.raise_http_error(response)
        return json.loads(response.text)

    def add_test_execution_to_test_plan(self, test_plan_id, test_execution_id):
        url = urljoin(self.api_uri, "graphql")
        headers = {'Content-type': 'application/json',
                   'Accept': 'text/plain',
                   'Authorization': 'Bearer {}'.format(self.access_token)}
        query_template = """
            mutation {{
                addTestExecutionsToTestPlan(
                    issueId: "{0}",
                    testExecIssueIds: "{1}"
                ) {{
                    addedTestExecutions
                    warning
                }}
            }}
        """
        query = query_template.format(test_plan_id, test_execution_id)
        response = requests.post(url, json={'query': query}, headers=headers)
        if response.status_code != 200:
            self.raise_http_error(response)
        return json.loads(response.text)

    def update_test_scenario_gherkin(self, test_id, gherkin):
        url = urljoin(self.api_uri, "graphql")
        headers = {'Content-type': 'application/json',
                   'Accept': 'text/plain',
                   'Authorization': 'Bearer {}'.format(self.access_token)}
        query_template = """
            mutation {{
                updateGherkinTestDefinition(
                    issueId: "{0}",
                    gherkin: "{1}") 
                    {{
                    issueId
                    gherkin
                }}
            }}
        """
        query = query_template.format(test_id, gherkin)
        response = requests.post(url, json={'query': query}, headers=headers)
        if response.status_code != 200:
            self.raise_http_error(response)
        return json.loads(response.text)

    def update_test_run_status_old(self, test_run_id, status, comments=None):
        url = urljoin(self.api_uri, "graphql")
        headers = {'Content-type': 'application/json',
                   'Accept': 'text/plain',
                   'Authorization': 'Bearer {}'.format(self.access_token)}
        query_template = """
            mutation {{
                updateTestRunStatus( 
                        id: "{0}",
                        status: "{1}"
                    ) 
            }}
        """
        query = query_template.format(test_run_id, status)
        response = requests.post(url, json={'query': query}, headers=headers)
        if response.status_code != 200:
            self.raise_http_error(response)
        if comments:
            self.update_test_run_comments(test_run_id, comments)
        return json.loads(response.text)

    def update_test_run_status(self, test_execution_key, test_execution_statuses):
        # preparing buld json
        test_execution_json = {
            "testExecutionKey": test_execution_key,
            "tests": test_execution_statuses
        }
        # performing bulk update
        url = urljoin(self.api_uri, "import/execution")
        headers = {'Content-type': 'application/json',
                   'Accept': 'text/plain',
                   'Authorization': 'Bearer {}'.format(self.access_token)}
        bulk_response = requests.post(url, data=json.dumps(test_execution_json), headers=headers)
        if bulk_response.status_code != 200:
            self.raise_http_error(bulk_response)

    def update_test_run_comments(self, test_run_id, comments):
        url = urljoin(self.api_uri, "graphql")
        headers = {'Content-type': 'application/json',
                   'Accept': 'text/plain',
                   'Authorization': 'Bearer {}'.format(self.access_token)}
        query_template = """
            mutation {{
                updateTestRun(
                        id: "{0}",
                        comment: "{1}"
                    )  {{
                        warnings
                    }}
            }}"""
        query = query_template.format(test_run_id, comments.replace('"', '\'').replace("\n", "\\n"))
        response = requests.post(url, json={'query': query}, headers=headers)
        if response.status_code != 200:
            self.raise_http_error(response)
        return json.loads(response.text)

    # noinspection PyMethodMayBeStatic
    def raise_http_error(self, response):
        status_code = response.status_code
        message = response.text
        request = response.request
        request_msg = "\n-url: {}\n-headers: {},\n-body: {}".format(request.url,
                                                                    request.headers,
                                                                    request.body)
        response_msg = "\n-code: {},\n-text: {}".format(status_code, message)
        raise Exception("\nREQUEST: {}\n\nRESPONSE: {}".format(request_msg, response_msg))
