# -*- encoding: utf-8 -*-
import logging
import traceback
from jira import JIRA
from .xray_graphql import XrayGraphQL

from .utils import steps_to_string

ISSUE_IDS = {}


class XrayProject(object):
    def __init__(self,
                 jira_instance_url,
                 jira_user_email,
                 jira_api_token,
                 xray_api_uri,
                 xray_client_id,
                 xray_client_secret):
        self.project = None
        self.test_plan = None
        self.test_exec = None
        self.jira = None
        self.dict_fields = None
        self.error = None
        self.xray_graphql = XrayGraphQL(xray_api_uri, xray_client_id, xray_client_secret)
        self.connect_to_jira(jira_instance_url, jira_user_email, jira_api_token)

    def connect_to_jira(self, jira_instance_url, jira_user_email, jira_api_token):
        try:
            self.jira = JIRA(jira_instance_url, basic_auth=(jira_user_email, jira_api_token))
        except Exception as exception:
            print(str(exception))
            print("The provided url '{}' was not found.".format(jira_instance_url))
            traceback.print_exc()
            exit(-1)

    def get_issues_types(self, project_key):
        meta = self.jira.createmeta(projectKeys=project_key, issuetypeNames=['Test', 'Test Set', 'Test Execution', 'Precondition', 'Test Plan'])
        projects = meta["projects"]
        for project in projects:
            if project["key"] == project_key:
                issuetypes = project["issuetypes"]
                for issue_type in issuetypes:
                    ISSUE_IDS[issue_type["name"]] = int(issue_type["id"])

    def get_project_by(self, find_by, value):
        for project in self.jira.projects():
            if getattr(project, find_by) == value:
                self.project = project
                return
        raise Exception("Project with {} = {} was not found".format(find_by, value))

    def get_issue(self, issue_type, issue_by, issue_value):
        """ Return a issue object from jira """
        filter = ''
        if issue_by in ['id', 'key']:
            filter = 'AND {}="{}"'.format(issue_by, issue_value)
        _, _, issues = self.get_issues(issue_type, filter=filter)
        if issue_by == 'summary':
            for issue in issues:
                if issue.fields.summary == issue_value:
                    return issue
        else:
            if not issues:
                raise Exception("{} with {}={} was not found".format(issue_type, issue_by, issue_value))
            return issues[0]

    def get_issues(self, issue_type, filter=''):
        """ :return dict_names{summary: issue}, dict_keys{key: issue.raw}, results[issue]"""
        dict_names = {}
        dict_keys = {}
        results = []
        fields = "key,summary,description,issuelinks,labels,status"
        start_at = 0
        max_results = 100  # 100 is the maximum number of records that jira retrieves
        query = 'project="{}" AND issuetype in ({}) {}'.format(self.project.id, ISSUE_IDS[issue_type], filter)
        while True:
            issues = self.jira.search_issues(jql_str=query, fields=fields, startAt=start_at, maxResults=max_results)
            for issue in issues:
                dict_names[issue.fields.summary] = issue
                dict_keys[issue.key] = issue.raw
                results.append(issue)
            start_at += max_results
            if len(issues) == 0:
                break
        return dict_names, dict_keys, results

    def get_tests_from_test_set(self, test_set_key):
        response = self.xray_graphql.get_tests_from_test_set(test_set_key)
        response_tests = response["data"]["getTestSets"]["results"][0]["tests"]["results"]
        tests_list = []
        for test in response_tests:
            if test:
                tests_list.append(test["jira"]["key"])
        return tests_list

    def get_tests_from_precondition(self, precondition_id):
        response = self.xray_graphql.get_tests_from_precondition(precondition_id)
        response_tests = response["data"]["getPrecondition"]["tests"]["results"]
        tests_list = []
        for test in response_tests:
            if test:
                tests_list.append(test["jira"]["key"])
        return tests_list

    def get_tests_from_test_run(self, test_exec_id):
        response = self.xray_graphql.get_tests_from_test_run(test_exec_id)
        tests_dict = {}
        if response:
            executed_tests = response["data"]["getTestRuns"]["results"]
            for test in executed_tests:
                if test["test"]:
                    tests_dict[test["test"]["jira"]["key"]] = test
        return tests_dict

    def get_tests_from_test_plan(self, test_exec_id):
        response = self.xray_graphql.get_tests_from_test_plan(test_exec_id)
        tests_dict = {}
        response_tests = response["data"]["getTestPlan"]["tests"]["results"]
        for test in response_tests:
            if test:
                tests_dict[test["jira"]["key"]] = test["jira"]
        return tests_dict

    def add_tests_to_test_plan(self, test_plan_id, tests_keys):
        self.xray_graphql.add_test_to_test_plan(test_plan_id, tests_keys)

    def add_tests_to_test_execution(self, test_exec_id, tests_keys):
        self.xray_graphql.add_test_to_test_execution(test_exec_id, tests_keys)

    def add_test_to_test_set(self, test_set_id, tests_ids):
        self.xray_graphql.add_test_to_test_set(test_set_id, tests_ids)

    def add_test_to_precondition(self, precondition_id, tests_ids):
        self.xray_graphql.add_test_to_precondition(precondition_id, tests_ids)

    def add_test_execution_to_test_plan(self, test_plan_id, test_execution_id):
        self.xray_graphql.add_test_execution_to_test_plan(test_plan_id, test_execution_id)

    def update_test_run_status_old(self, test_run_id, status, comments):
        self.xray_graphql.update_test_run_status(test_run_id, status, comments)

    def update_test_run_status(self, test_execution_key, test_execution_statuses):
        self.xray_graphql.update_test_run_status(test_execution_key, test_execution_statuses)

    def update_test_scenario_gherkin(self, test_id, gherkin):
        self.xray_graphql.update_test_scenario_gherkin(test_id, gherkin)

    def create_tests(self, scenarios):
        """
        :param scenarios: list of dicts
        """
        try:
            tests_list = []
            for scenario in scenarios:
                gherkin_def = ""
                for step in steps_to_string(scenario, scenario['steps']).split("\n"):
                    gherkin_def += step + "\n"
                test = {
                        "testtype": "Cucumber",
                        "fields": {"project": {"key": self.project.key},
                                   "summary": scenario['name'].strip(),
                                   "labels": scenario["tags"],
                                   "description": gherkin_def,
                                   "customfield_10054": {"value": "Forecasting"}},
                        "gherkin_def": gherkin_def,
                }
                tests_list.append(test)
            response = self.xray_graphql.create_tests(tests_list)
            if response["status"].lower() == "failed":
                print('The following scenarios were not inserted:\n\t{}'.format(',\n\t'.join(map(repr, tests_list))))
                self.error = True
                return None
            comma_separated_issues = ','.join([issue["key"] for issue in response["result"]["issues"]])
            dict_names, dict_keys, created_tests = self.get_issues("Test", "and issuekey in ({})".format(comma_separated_issues))
            return dict_names, dict_keys, created_tests
        except Exception as ex:
            logging.error(ex)
            print('Error when trying to create test scenarios')
            traceback.print_exc()

    def create_test_set(self, summary):
        try:
            response = self.xray_graphql.create_test_set(project_key=self.project.key,
                                                         summary=summary)
            test_set_key = response["data"]["createTestSet"]["testSet"]["jira"]["key"]
            dict_names, dict_keys, created_test_set = self.get_issues("Test Set", "and issuekey in ({})".format(test_set_key))
            return dict_names, dict_keys, created_test_set
        except Exception as ex:
            logging.error(ex)
            print('Error when trying to create the test set')
            traceback.print_exc()

    def create_preconditions(self, preconditions):
        try:
            precondition_keys = []
            created_precond = {}
            for precondition in preconditions:
                if precondition:
                    precond_name, precond_steps = precondition
                    gherkin_def = ""
                    for step in precond_steps:
                        gherkin_def += step["step_type"] + " " + step["name"].replace("\"", "\\\"") + "\\n"
                    response = self.xray_graphql.create_precondition(self.project.key, precond_name, gherkin_def)
                    precondition_key = response["data"]["createPrecondition"]["precondition"]["jira"]["key"]
                    precondition_keys.append(precondition_key)
            if precondition_keys:
                dict_names, dict_keys, created_precond = self.get_issues("Precondition", "and issuekey in ('{}')".format("','".join(precondition_keys)))
            return created_precond
        except Exception as ex:
            logging.error(ex)
            print('Error when trying to create preconditions')
            traceback.print_exc()

    def create_test_plan(self, test_plan_summary):
        try:
            response = self.xray_graphql.create_test_plan(self.project.key, test_plan_summary)
            test_plan_key = response["data"]["createTestPlan"]["testPlan"]["jira"]["key"]
            dict_names, dict_keys, created_plan = self.get_issues("Test Plan", "and issuekey in ({})".format(test_plan_key))
            return dict_names, dict_keys, created_plan
        except Exception as ex:
            logging.error(ex)
            print('Error when trying to create the test plan')
            traceback.print_exc()

    def create_test_execution(self, test_execution_summary):
        try:
            response = self.xray_graphql.create_test_execution(self.project.key, test_execution_summary)
            test_exec_key = response["data"]["createTestExecution"]["testExecution"]["jira"]["key"]
            dict_names, dict_keys, created_test_exec = self.get_issues("Test Execution", "and issuekey in ({})".format(test_exec_key))
            return dict_names, dict_keys, created_test_exec
        except Exception as ex:
            logging.error(ex)
            print('Error when trying to create the test execution')
            traceback.print_exc()

    def link_test_to_jira_elem(self, jira_elem_key, test_key):
        self.jira.create_issue_link(type='tests', inwardIssue=test_key, outwardIssue=jira_elem_key)

    def create_dict_fields(self):
        self.dict_fields = {}
        fields = self.jira.fields()
        for field in fields:
            if isinstance(field, dict):
                if field['custom']:
                    self.dict_fields[field['name']] = field['id']
