
from setuptools import setup, find_packages


setup(
    name="behavex-xray",
    version="1.0.1",
    # long_description=open("README.txt").read(),

    author="Hernan Rey",
    author_email="behavex_xray_users@googlegroups.com",

    packages=find_packages(exclude=['behavex_tests']),
    include_package_data=True,

    description="Library to sync BehaveX elements with Xray for Jira",

    entry_points={
        'console_scripts': [
            'sync_behavex_xray=behavex_xray.sync_behavex:main'
        ]
    },

    install_requires=["jira==2.0.0",
                      "configobj",
                      "requests"],

)
