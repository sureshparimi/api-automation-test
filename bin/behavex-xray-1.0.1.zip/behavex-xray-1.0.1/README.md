# Xray synchronization library

The behavex-xray library is provided to sync BehaveX test scenarios and test execution results with Jira.  
Jira has embedded test management capabilities, an overall test inventory generated from completed acceptance tests. The behavex-xray library allows you to automatically generate the test plans, test executions, test sets, preconditions and test scenarios using the JSON report that comes from a specific BehaveX test execution.  
For details about the jira test management tool:
  * https://jira.atlassian.com/

Basically, the library consumes the **results.json** file generated from a BehaveX test execution and process all the information, includding not only the test specifications but also the status of executed test, allowing the team to complete a regression test cycle by enabling testers to set the status of Manual test scenarios.

## Install the behavex-xray library

You can install the behavex-xray library in two steps:  

* Download the [latest library package](TBD) and store it in a local folder in your machine

* Execute the following command to install the behavex-xray library:
> *pip install \<behavex-xray-package\>*

Note: If you are inside the Intel network, most probably you will need to provide the proxy as stated above, as the library downloads dependencies from [pypy](https://pypi.python.org/pypi)

## Creating a basic configuration file

To synchronize the test scenarios and test execution results you need to provide a configuration file (.cfg), that will contain the credentials to Jira and information about the Test Plan, Test Suite and Test Set you aim to create.
The most basic configuration looks like the following one:

> [jira]  
> instance_url=https://\<jira_domain\>  
> username=\<jira_username\>  
> password=\<jira_password\>  
>   
> [sync]  
> json_path=\<path_to_results.json\>  
> project_key=\<project_key\>  
> test_plan_summary=\<test_plan_summary\>  
> test_exec_summary=\<test_exec_summary\>  

#### Other configuration parameters for [sync]:
> project_id=\<test_project_id\>  
> test_plan_id=\<test_plan_id\>  
> test_plan_key=\<test_plan_key\>  
> story_tag_regex=\<story_tag_regex\>  
> threads_number=\<threads_number\>  

 Considerations:
 * The provided username should have read/write rights in the project where the test plan will be created
 * The test_project should already exist in the username namespace if **test_project_id** is in the configuration file
 * The test plan will be created if they don't exist 
 * The stories issues should already exist in project and **<story_tag_regex>** must be '[**PROJECT-KEY**]-[0-9]' 

## Synchronyzing test scenarios and test results

Once the configuration file has been created, you can easily create a test execution in the project you specify. The generated test execution will contain the test scenarios that come from the resulting **results.json** file associated to a specific test execution.
Run this command to perform the operation:
> *sync_behavex_xray -c \<path_config_file\>*  
> (e.g. sync_behavex_xray -c sync_xray.cfg)  
  
The command above will perform the following actions:  
  * Creates a new Test Plan if it doesn't exist (mapping by test plan name). Otherwise, it will use the existing one.
  * Creates a new Test Execution.
  * Create a new Test Set for each feature in **results.json** if it doesn’t exist (mapping by test set summary). Otherwise, it will use the existing one.
  * Creates a new precondition associated with the background of each feature if it does not exist in the test plan (mapping by pre-condition summary). Otherwise, it will use the existing one.
  * Creates and add the test scenarios from the **results.json** file to the Test Execution and Test Plan.
  * Update Test status with (PASS, FAIL or TODO).
  * Link Test sceanario to Story based in scenario tags.
  * Add Tests to the Test Set and Pre-conditions.  

## Updating an existing Test Execution
Test execution can be updated to add more test scenarios or to update the content and status of existing test scenarios. In order to do this, you just need to provide the *-u* or *--update* argument:
> *sync_behavex_xray -c \<config_file_name\> --update \<test_execution_key\>*  
> (e.g. sync_behavex_xray -c xray.cfg --update SEC-9019)  

Note: The test_execution_key should already exist in the username namespace

The command above will perform the following actions:
  * Look for the Test execution and Test scenarios asociates.
  * Add Test scenarios if they do not exist in Test Execution.
  * Check the status, steps, tags and update if they differs from the result.json.

## Flags
> **-c** / **--config** \<config_file_path\>  

> **-u** / **--update** \<test_execution_key\>  

> **-swd** / **--sync-with-duplicates**  

> **-str** / **--story**-tag-regex \<story-tag-regex\>  

> **-us** / **--username** \<username\>  

> **-p** / **--password** \<password\>  

> **-iu** / **--instance_url** \<instance_url\>  

> **-jp** / **--json_path** \<json_path\>  

> **-pi** / **--project_id** \<project_id\>  

> **-pk** / **--project_key** \<project_key\>  

> **-tpk** / **--test_plan_key** \<test_plan_key\>  

> **-tps** / **--test_plan_summary** \<test_plan_summary\>  
