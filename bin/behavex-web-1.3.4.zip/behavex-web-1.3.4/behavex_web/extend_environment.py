import os
import logging
import platform
import shutil
import sys

from behave.runner import ModelRunner
from selenium import webdriver
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
from behavex import environment as bhx_benv
from behavex.outputs.report_utils import normalize_filename
from behavex.utils import try_operate_descriptor
# cStringIO has been changed to StringIO or io
try:
    from StringIO import StringIO
except ImportError:
    from io import StringIO
from behaving.web import environment as bng_benv
if platform.system().upper() == "LINUX":
    from xvfbwrapper import Xvfb

FWK_PATH = os.getenv('BEHAVEX_PATH')

hooks_already_set = False


def extend_behave_hooks():
    """
    Extend Behave hooks with BehaveX hooks code.
    """
    global hooks_already_set
    behave_run_hook = ModelRunner.run_hook
    behavex_env = sys.modules[__name__]

    def run_hook(self, name, context, *args):
        if name == 'before_all':
            # noinspection PyUnresolvedReferences
            behavex_env.before_all(context)
            behave_run_hook(self, name, context, *args)
        elif name == 'before_feature':
            behave_run_hook(self, name, context, *args)
            # noinspection PyUnresolvedReferences
            behavex_env.before_feature(context, *args)
        elif name == 'before_scenario':
            behave_run_hook(self, name, context, *args)
            # noinspection PyUnresolvedReferences
            behavex_env.before_scenario(context, *args)
        elif name == 'after_step':
            behave_run_hook(self, name, context, *args)
            # noinspection PyUnresolvedReferences
            behavex_env.after_step(context, *args)
        elif name == 'after_scenario':
            behave_run_hook(self, name, context, *args)
            # noinspection PyUnresolvedReferences
            behavex_env.after_scenario(context, *args)
        elif name == 'after_feature':
            # noinspection PyUnresolvedReferences
            behavex_env.after_feature(context, *args)
            behave_run_hook(self, name, context, *args)
        elif name == 'after_all':
            # noinspection PyUnresolvedReferences
            behavex_env.after_all(context, *args)
            behave_run_hook(self, name, context, *args)
        else:
            behave_run_hook(self, name, context, *args)

    if not hooks_already_set:
        hooks_already_set = True
        ModelRunner.run_hook = run_hook


def before_all(context):
    try:
        _copy_screenshot_utilities()
        bng_benv.before_all(context)
        if "BROWSER" in os.environ:
            context.selected_browser = os.environ.get('BROWSER').lower()
        else:
            context.selected_browser = context.config.userdata.get("browser", "chrome")

        if "GRID_URL" in os.environ:
            context.grid_url = os.environ.get('GRID_URL')
        else:
            context.grid_url = context.config.userdata.get("grid_url", None)

        if "XVFB" in os.environ:
            context.use_xvfb = os.environ.get('XVFB')
        else:
            context.use_xvfb = context.config.userdata.get("XVFB", None)

        # Configuring initial setup for local/remote test executions
        if context.grid_url:
            logging.info("Running tests in remote selenium grid...")
            context.remote_webdriver = True
            if context.selected_browser == 'chrome':
                desired_capabilities = DesiredCapabilities.CHROME
                options = webdriver.ChromeOptions()
                options.add_argument('--no-sandbox')
                desired_capabilities.update(options.to_capabilities())
            elif context.selected_browser == 'firefox':
                desired_capabilities = DesiredCapabilities.FIREFOX
                options = webdriver.FirefoxOptions()
                desired_capabilities.update(options.to_capabilities())
            elif context.selected_browser == 'safari':
                desired_capabilities = DesiredCapabilities.SAFARI
            elif context.selected_browser == 'phantomjs':
                desired_capabilities = DesiredCapabilities.PHANTOMJS
            elif context.selected_browser == 'android':
                desired_capabilities = DesiredCapabilities.ANDROID
            elif context.selected_browser == 'ipad':
                desired_capabilities = DesiredCapabilities.IPAD
            elif context.selected_browser == 'opera':
                desired_capabilities = DesiredCapabilities.OPERA
            elif context.selected_browser == 'internet explorer' or context.selected_browser == 'internetexplorer':
                desired_capabilities = DesiredCapabilities.INTERNETEXPLORER
                desired_capabilities['ignoreProtectedModeSettings'] = 'true'
            context.browser_args = {'command_executor': context.grid_url,
                                    'desired_capabilities': desired_capabilities}
            logging.info("\n-----------------------------\n"
                         "Default grid configuration: {} \n"
                         "For additional grid configurations, please "
                         "update the 'context.browser_args' variable\n"
                         "-----------------------------".format(context.browser_args))
        else:
            if context.selected_browser in ("firefox", "chrome"):
                if context.use_xvfb and platform.system().upper() == "LINUX":
                    logging.info("Running tests using XVFB..")
                    context.bhx_xvfb = Xvfb(width=1280, height=720)
                    context.bhx_xvfb.start()
                    context.default_browser = context.selected_browser
                else:
                    context.default_browser = context.selected_browser
            else:
                logging.info("\n-----------------------------\n"
                             "{} is not a valid option for executions in local browsers\n"
                             "-----------------------------".format(context.selected_browser))
                exit()

        # Setting default logging level for selenium for web based tests
        logger_name = 'selenium.webdriver.remote.remote_connection'
        selenium_logger = logging.getLogger(logger_name)
        selenium_logger.propagate = False
        selenium_logger.setLevel(logging.WARNING)
    except Exception as ex:
        bhx_benv._log_exception_and_continue("before_all (behavex-web)", exception=ex)


def before_feature(context, feature):
    bng_benv.before_feature(context, feature)


def before_scenario(context, scenario):
    bng_benv.before_scenario(context, scenario)
    try:
        # Setup initial configuration for capturing screenshots
        context.capture_screens_after_step = False
        context.bhx_image_hash = None
        context.bhx_capture_screens_folder = context.log_path
        context.bhx_capture_screens_number = 0
        context.bhx_captured_screens = {}
        context.bhx_previous_steps = []
        context.bhx_image_stream = None
        context.bhx_log_stream = StringIO()
        context.bhx_step_log_handler = logging.StreamHandler(context.bhx_log_stream)
        # Adding a new log handler to logger
        context.bhx_step_log_handler.setFormatter(bhx_benv._get_log_formatter())
        logging.getLogger().addHandler(context.bhx_step_log_handler)
    except Exception as ex:
        bhx_benv._log_exception_and_continue("before_scenario (behavex-web)", exception=ex)


def after_step(context, step):
    try:
        if context.bhx_inside_scenario:
            from behavex_web.utils.screenshots import screenshots
            screenshots.capture_browser_image(context, step=normalize_filename(step.name))
    except Exception as ex:
        bhx_benv._log_exception_and_continue("after_step (behavex-web)", exception=ex)


def after_scenario(context, scenario):
    try:
        if hasattr(context, 'capture_screens_after_step') \
                and context.capture_screens_after_step is True or scenario.status == 'failed':
            from behavex_web.utils.screenshots import screenshots
            screenshots.dump_screens(context)
            captions = screenshots.get_captions(context)
            screenshots.generate_gallery(context.bhx_capture_screens_folder,
                                         title=scenario.name,
                                         captions=captions)
        if scenario.status in ('failed', 'untested') and 'AUTORETRY' in scenario.tags \
                and os.environ.get('AUTORETRY_ATTEMPT', None) == '0':
            bng_benv.teardown(context)
        else:
            bng_benv.after_scenario(context, scenario)
        _close_log_handler(context.bhx_step_log_handler)
    except Exception as ex:
        bhx_benv._log_exception_and_continue("after_scenario (behavex-web)", exception=ex)


def after_feature(context, feature):
    bng_benv.after_feature(context, feature)


def after_all(context):
    if "browsers" in context:
        bng_benv.after_all(context)
        try:
            if context.use_xvfb and platform.system().upper() == "LINUX":
                context.bhx_xvfb.stop()
        except Exception as ex:
            bhx_benv._log_exception_and_continue("after_all (behavex-web)", exception=ex)


def _copy_screenshot_utilities():
    destination_path = os.path.join(os.getenv('LOGS'), 'screenshots_utils')
    if not os.path.exists(destination_path):
        current_path = os.path.dirname(os.path.abspath(__file__))
        screenshots_path = [current_path, 'utils', 'screenshots', 'support_files']
        screenshots_path = os.path.join(*screenshots_path)
        if os.path.exists(destination_path):
            try_operate_descriptor(destination_path, lambda: shutil.rmtree(destination_path))

        def execution(): return shutil.copytree(screenshots_path, destination_path)
        try_operate_descriptor(destination_path, execution)


def _close_log_handler(handler):
    """Closing current log handlers and removing them from logger"""
    if handler is not None:
        if hasattr(handler, 'stream') and hasattr(handler.stream, 'close'):
            handler.stream.close()
        logging.getLogger().removeHandler(handler)

extend_behave_hooks()

