"""
This module is using for support in screenshots
"""
